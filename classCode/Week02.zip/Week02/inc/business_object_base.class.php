<?php
class BusinessObjectBase {

  function Load() {
  }

  function Save() {
  }

  function Validate() {
  }
}
?>